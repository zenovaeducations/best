import { initializeApp } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-app.js";
import {
  getAuth,
  signInWithEmailAndPassword,
  GoogleAuthProvider,
  signInWithPopup,
  sendPasswordResetEmail,
  setPersistence,
  browserLocalPersistence,
  browserSessionPersistence
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

import firebaseConfig from "./firebase-config.js";

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

const loginForm = document.getElementById("loginForm");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const rememberMe = document.getElementById("rememberMe");
const loginBtn = document.getElementById("loginBtn");
const googleLogin = document.getElementById("googleLogin");
const forgotPassword = document.getElementById("forgotPassword");
const togglePassword = document.getElementById("togglePassword");
const message = document.getElementById("message");

function showMessage(text,type=""){
  message.textContent=text;
  message.className="message";
  if(type) message.classList.add(type);
}

function setLoading(loading){
  loginBtn.disabled=loading;
  googleLogin.disabled=loading;
  loginBtn.textContent=loading?"LOGGING IN...":"LOGIN";
}

togglePassword.addEventListener("click",()=>{
  const hidden=passwordInput.type==="password";
  passwordInput.type=hidden?"text":"password";
  togglePassword.textContent=hidden?"HIDE":"SHOW";
});

loginForm.addEventListener("submit",async(e)=>{
  e.preventDefault();
  const email=emailInput.value.trim();
  const password=passwordInput.value;

  if(!email||!password){
    showMessage("Please enter your email and password.","error");
    return;
  }

  setLoading(true);
  try{
    await setPersistence(auth,rememberMe.checked?browserLocalPersistence:browserSessionPersistence);
    await signInWithEmailAndPassword(auth,email,password);
    showMessage("Login successful. Redirecting...","success");

    // Change this later to your actual dashboard path.
    setTimeout(()=>{window.location.href="../dashboard/index.html";},800);
  }catch(error){
    console.error(error);
    let text="Unable to login. Please check your details.";
    if(["auth/invalid-credential","auth/wrong-password","auth/user-not-found"].includes(error.code)) text="Invalid email or password.";
    else if(error.code==="auth/too-many-requests") text="Too many attempts. Please try again later.";
    else if(error.code==="auth/invalid-email") text="Please enter a valid email address.";
    showMessage(text,"error");
    setLoading(false);
  }
});

googleLogin.addEventListener("click",async()=>{
  setLoading(true);
  try{
    const provider=new GoogleAuthProvider();
    await setPersistence(auth,rememberMe.checked?browserLocalPersistence:browserSessionPersistence);
    await signInWithPopup(auth,provider);
    showMessage("Google login successful. Redirecting...","success");
    setTimeout(()=>{window.location.href="../dashboard/index.html";},800);
  }catch(error){
    console.error(error);
    if(error.code==="auth/popup-closed-by-user") showMessage("Google login was cancelled.","error");
    else if(error.code==="auth/popup-blocked") showMessage("Please allow popups for Google login.","error");
    else showMessage("Google login failed. Please try again.","error");
    setLoading(false);
  }
});

forgotPassword.addEventListener("click",async()=>{
  const email=emailInput.value.trim();

  if(!email){
    showMessage("Enter your email first, then click Forgot password.","error");
    emailInput.focus();
    return;
  }

  try{
    await sendPasswordResetEmail(auth,email);
    showMessage("Password reset email sent. Check your inbox.","success");
  }catch(error){
    console.error(error);
    if(error.code==="auth/user-not-found") showMessage("No account was found with this email.","error");
    else if(error.code==="auth/invalid-email") showMessage("Please enter a valid email address.","error");
    else showMessage("Unable to send reset email. Please try again.","error");
  }
});
